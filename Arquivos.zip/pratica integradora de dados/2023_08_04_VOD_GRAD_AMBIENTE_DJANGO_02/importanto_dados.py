import pandas as pd

dados = pd.read_csv("titles.csv")