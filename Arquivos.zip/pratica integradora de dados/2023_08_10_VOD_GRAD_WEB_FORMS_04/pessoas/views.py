from django.shortcuts import render, get_object_or_404, redirect
from rest_framework import viewsets
from .models import Pessoa
from .serializers import PessoaSerializer
from django.views.decorators.csrf import csrf_exempt

class PessoaViewSet(viewsets.ModelViewSet):
    queryset = Pessoa.objects.all()
    serializer_class = PessoaSerializer

def lista_pessoas(request):
    pessoas = Pessoa.objects.all()
    media_idades = Pessoa.objects.aggregate(media=Avg('idade'))['media']
    return render(request, 'pessoas/lista.html', {'pessoas': pessoas, 'media_idades': media_idades})

@csrf_exempt
def criar_pessoa(request):
    if request.method == "POST":
        nome = request.POST.get("nome")
        idade = request.POST.get("idade")
        pessoa = Pessoa.objects.create(nome=nome, idade=idade)
        return redirect('lista_pessoas')
    return render(request, 'pessoas/criar.html')

@csrf_exempt
def atualizar_pessoa(request, pessoa_id):
    pessoa = get_object_or_404(Pessoa, id=pessoa_id)
    if request.method == "POST":
        pessoa.nome = request.POST.get("nome")
        pessoa.idade = request.POST.get("idade")
        pessoa.save()
        return redirect('lista_pessoas')
    return render(request, 'pessoas/atualizar.html', {'pessoa': pessoa})

def deletar_pessoa(request, pessoa_id):
    pessoa = get_object_or_404(Pessoa, id=pessoa_id)
    pessoa.delete()
    return redirect('lista_pessoas')