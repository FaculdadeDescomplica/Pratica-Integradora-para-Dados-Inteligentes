from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PessoaViewSet, lista_pessoas, criar_pessoa, atualizar_pessoa, deletar_pessoa

outer = DefaultRouter()
router.register(r'pessoas', PessoaViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('pessoas/', lista_pessoas, name='lista_pessoas'),
    path('pessoas/criar/', criar_pessoa, name='criar_pessoa'),
    path('pessoas/atualizar/<int:pessoa_id>/', atualizar_pessoa, name='atualizar_pessoa'),
    path('pessoas/deletar/<int:pessoa_id>/', deletar_pessoa, name='deletar_pessoa'),
]
