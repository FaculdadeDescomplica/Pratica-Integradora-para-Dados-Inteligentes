from django.core.paginator import Paginator
from django.shortcuts import render
from .models import Pessoa

def lista_pessoas(request):
    pessoas = Pessoa.objects.all()
    
    # Paginação: definir quantos itens por página
    paginator = Paginator(pessoas, 10)  # 10 pessoas por página
    
    # Pegar o número da página atual (se não houver, vai ser a página 1)
    page_number = request.GET.get('page')  # 'page' é o nome do parâmetro de query
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'pessoas/lista.html', {'page_obj': page_obj})