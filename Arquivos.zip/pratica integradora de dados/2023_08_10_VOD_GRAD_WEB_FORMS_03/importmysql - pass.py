import mysql.connector

# Configuracces de conexo com o banco de dados
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "**",
    "database": "teste"
}

try:
    # Conectar ao banco de dados
    connection = mysql.connector.connect(**db_config)

    if connection.is_connected(): 
        cursor = connection.cursor()

        # Exemplo de consulta
        query = "SELECT * FROM teste" 
        cursor.execute(query)

        # Obtendo os resultados results cursor.fetchall() for row in results: print(row)
        results = cursor.fetchall()
        for row in results:
                print(row)

except mysql.connector.Error as err:
    print("Erro ao conectar ou consultar o banco de dados:", err)
finally:
    # Fechar cursor e conexo
    if 'cursor' in locals() and cursor is not None:
         cursor.close()
    if 'connection' in locals() and connection.is_connected():
         connection.close()